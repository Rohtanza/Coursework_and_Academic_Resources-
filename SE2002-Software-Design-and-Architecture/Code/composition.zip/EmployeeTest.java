
public class EmployeeTest {
public static void main(String[] args) {
		
		Employee employee = new Employee( "Bob", "Williams", 4, 30, 1949);
		System.out.println( employee );

	}
}
