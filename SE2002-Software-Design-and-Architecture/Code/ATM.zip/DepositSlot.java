
public class DepositSlot {

		public boolean isEnvelopeReceived()
		{
			return true; 
		}
	//*********************************************
}