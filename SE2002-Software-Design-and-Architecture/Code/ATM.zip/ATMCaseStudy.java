
public class ATMCaseStudy {

	public static void main(String[] args) {
	
		ATM theATM = new ATM();
		theATM.run();

	}
	
}
