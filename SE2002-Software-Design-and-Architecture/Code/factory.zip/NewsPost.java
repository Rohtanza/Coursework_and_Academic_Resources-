

public class NewsPost extends Post{

	private String headline;
	
	public String getHeadline() {
		return headline;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}

	//_______________________________________________
}
