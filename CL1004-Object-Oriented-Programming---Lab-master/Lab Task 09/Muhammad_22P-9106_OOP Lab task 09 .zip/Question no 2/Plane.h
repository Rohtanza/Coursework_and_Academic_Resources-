//
// Created by rayhan on 3/31/23.
//

#ifndef QUESTION_NO_2_PLANE_H
#define QUESTION_NO_2_PLANE_H


class Plane {
protected:
    double maxAltitude;
public:
    Plane(double maxAltitude);
    void fly(void);

};


#endif //QUESTION_NO_2_PLANE_H
