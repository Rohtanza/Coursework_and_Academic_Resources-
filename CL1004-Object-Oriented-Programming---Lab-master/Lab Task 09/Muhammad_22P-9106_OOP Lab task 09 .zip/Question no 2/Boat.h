//
// Created by rayhan on 3/31/23.
//

#ifndef QUESTION_NO_2_BOAT_H
#define QUESTION_NO_2_BOAT_H


class Boat {
protected:
    double boatLength;
public:
    Boat(int boatLength);
    void swin();
};


#endif //QUESTION_NO_2_BOAT_H
