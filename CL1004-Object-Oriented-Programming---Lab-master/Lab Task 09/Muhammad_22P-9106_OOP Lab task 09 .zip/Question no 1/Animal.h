//
// Created by rayhan on 3/31/23.
//

#ifndef OOP_LAB_TASK_09_ANIMAL_H
#define OOP_LAB_TASK_09_ANIMAL_H

#include <string>

using namespace std;

class Animal {
public:
    string name;
    int age;

    void speak(void);

};


#endif //OOP_LAB_TASK_09_ANIMAL_H
