#include <iostream>
#include "Contact.h"
#include "DateOfBirth.h"

int main() {
    Contact ContactList(size());
    ContactList.CrowdList();
    ContactList.Menu();
    return 0;
}
