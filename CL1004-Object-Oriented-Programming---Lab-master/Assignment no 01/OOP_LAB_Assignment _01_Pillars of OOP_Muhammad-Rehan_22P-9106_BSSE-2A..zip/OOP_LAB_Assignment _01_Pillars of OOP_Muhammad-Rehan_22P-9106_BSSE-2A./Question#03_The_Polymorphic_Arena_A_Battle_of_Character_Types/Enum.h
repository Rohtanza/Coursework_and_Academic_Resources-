//
// Created by _rayhan on 4/27/23.
//

/*
 * This header file contain our enum, so we dont
 * have to add it to every file, we will just include
 * this header.
 * */

enum WeaponType {
    swords,
    fireballs,
    daggers,
};

