// OOP LAB Task No 08 | Question no 2 | Muhammad Rehan | 22P-9106 | BSE-2A


#include <iostream>
#include "Employee.h"
#include "HourlyEmployee.h"

using namespace std;

int main() {
    Operations();
    return 0;
}
