//
// Created by _rayhan on 5/5/23.
//

#include "Course.h"

Course::Course(const string &courseCode, const string &courseName, const string &instructor) : course_code(courseCode),
                                                                                               course_name(courseName),
                                                                                               instructor(instructor) {}
