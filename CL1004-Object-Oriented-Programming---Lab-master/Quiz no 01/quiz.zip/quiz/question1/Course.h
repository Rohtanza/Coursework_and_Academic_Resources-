//
// Created by _rayhan on 5/5/23.
//

#ifndef QUESTION1_COURSE_H
#define QUESTION1_COURSE_H


#include <string>

using namespace std;

class Course {
public:
    Course(const string &courseCode, const string &courseName, const string &instructor);


    string course_name;
    string course_code;
    string instructor;
};


#endif //QUESTION1_COURSE_H
