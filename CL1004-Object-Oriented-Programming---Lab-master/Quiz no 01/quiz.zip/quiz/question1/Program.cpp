//
// Created by _rayhan on 5/5/23.
//

#include <iostream>
#include <limits>
#include "Program.h"

using namespace std;

Program::Program() {


    cout<<"Enter Your Program name: ",getline(cin,name);
    cout<<"Enter the ID: ", getline(cin,ID);

    cout<<"Enter your course count: ",cin>>count;

    Course* Courselist[count];


    for (int i = 0; i < count; ++i) {

        addCourse();
    }



}

void Program::addCourse() {

    string course_name;
    string course_code;
    string instructor;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');



    for (int i = 0; i < count; ++i) {
        cout<<"Enter Your Course name: ",getline(cin,course_name);
        cout<<"Enter the course code: ", getline(cin,course_code);
        cout<<"Enter the course instructor: ", getline(cin,instructor);
        Courselist[i]=Course(course_code,course_name,instructor);
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

    }

}

Program::~Program() {
    delete Courselist;

}

void Program::display() {


    cout<<"Enter Program is :"<<name<<endl;
    cout<<"The ID is "<<ID<<endl;
    cout<<"\tThe courses are: "<<endl;
    for (int i = 0; i < count; ++i) {

        cout<<"The Course name is"<<Courselist[i].course_name;
        cout<<"The Course code is"<<Courselist[i].course_code;
        cout<<"The instructor is "<<Courselist[i].instructor;



    }


}


