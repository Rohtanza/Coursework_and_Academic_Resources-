//
// Created by _rayhan on 5/5/23.
//

#ifndef QUESTION1_PROGRAM_H
#define QUESTION1_PROGRAM_H
#include <string>
#include <vector>

#include "Course.h"
using namespace std;


class Program {
public:

private:

    string name;
    string ID;
    Course* Courselist;

    int count;
public:
    Program();
    void addCourse();

    virtual ~Program();

    void display();

};


#endif //QUESTION1_PROGRAM_H
