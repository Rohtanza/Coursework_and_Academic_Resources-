#include <iostream>
#include "Program.h"

int main() {

    Program SoftwareEngineering;

    SoftwareEngineering.display();

    return 0;
}
