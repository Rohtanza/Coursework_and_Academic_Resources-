//
// Created by _rayhan on 5/5/23.
//

#include <iostream>
#include "car.h"

void car::displayDetials() {
    Vechile::displayDetials();
    cout<<"The doors are :"<<door<<endl;
    cout<<"the max speed is :"<<maxspeed<<endl;


}

car::car(const string &id, const string &model, int year, int door, double maxspeed) : Vechile(id, model, year),
                                                                                       door(door), maxspeed(maxspeed) {}
