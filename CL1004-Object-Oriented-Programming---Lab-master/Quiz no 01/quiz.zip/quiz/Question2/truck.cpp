//
// Created by _rayhan on 5/5/23.
//

#include <iostream>
#include "truck.h"

void truck::displayDetials() {
    Vechile::displayDetials();
    cout<<"the payload capacity is : "<<payloadcapacity<<endl;
}

truck::truck(const string &id, const string &model, int year, double payloadcapacity) : Vechile(id, model, year),
                                                                                        payloadcapacity(
                                                                                                payloadcapacity) {}
