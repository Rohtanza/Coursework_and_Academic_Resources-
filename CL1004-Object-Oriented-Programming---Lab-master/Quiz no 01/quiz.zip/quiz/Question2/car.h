//
// Created by _rayhan on 5/5/23.
//

#ifndef QUESTION2_CAR_H
#define QUESTION2_CAR_H


#include "Vechile.h"

class car : public Vechile{

    int door;
public:
    car(const string &id, const string &model, int year, int door, double maxspeed);

private:
    double maxspeed;

public:
    void displayDetials() override;
};


#endif //QUESTION2_CAR_H
