//
// Created by _rayhan on 5/5/23.
//

#ifndef QUESTION2_VECHILE_H
#define QUESTION2_VECHILE_H
#include <string>

using namespace std;

class Vechile {

    string ID;
    string Model;
public:
    Vechile(const string &id, const string &model, int year);

private:
    int year;

public:

    virtual void displayDetials();


};


#endif //QUESTION2_VECHILE_H
