//
// Created by _rayhan on 5/5/23.
//

#ifndef QUESTION2_TRUCK_H
#define QUESTION2_TRUCK_H


#include "Vechile.h"

class truck : public Vechile{

    double payloadcapacity;
public:
    truck(const string &id, const string &model, int year, double payloadcapacity);

public:
    void displayDetials() override;

};


#endif //QUESTION2_TRUCK_H
