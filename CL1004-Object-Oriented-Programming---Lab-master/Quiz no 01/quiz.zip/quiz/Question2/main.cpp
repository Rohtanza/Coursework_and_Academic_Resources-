#include <iostream>
#include "Vechile.h"
#include "car.h"
#include "truck.h"

int main() {


    Vechile *CarsandTrucks[]={
            new car("123","model123",2008,4,200),

            new truck("123","modeltruck123",2018,2000),

            new car("123","model123",2008,4,200),

            new truck("123","modeltruck123",2018,2000),

            new car("123","model123",2008,4,200)


    };

    for (auto i:CarsandTrucks) {
        i->displayDetials();

    }
    for (int i = 0; i < 5; ++i)
        delete CarsandTrucks[i];


    return 0;
}
