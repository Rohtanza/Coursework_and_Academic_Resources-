//
// Created by _rayhan on 5/5/23.
//

#include <iostream>
#include "Vechile.h"

void Vechile::displayDetials() {



}

Vechile::Vechile(const string &id, const string &model, int year) : ID(id), Model(model), year(year) {}
