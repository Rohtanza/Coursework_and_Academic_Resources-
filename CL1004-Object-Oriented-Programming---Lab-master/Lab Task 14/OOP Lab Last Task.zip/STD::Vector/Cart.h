//
// Created by _rohtanza_ on 5/13/23.
//

#ifndef STD__VECTOR_CART_H
#define STD__VECTOR_CART_H


#include <vector>
#include "Item.h"

class Cart {
    std::vector<Item> *shoppingCart;
    static const std::string products[2][6];
public:
    Cart();

    void distoryCart();

    void displayCart();

    static void productList();

    void operations();

    void addItem();

    void removeItem();

    void clearCart();

    void updateCart();

    static void Menu();

    bool isEmpty();

    static bool withinRange(int low, int high, int choice);


};


#endif //STD__VECTOR_CART_H
