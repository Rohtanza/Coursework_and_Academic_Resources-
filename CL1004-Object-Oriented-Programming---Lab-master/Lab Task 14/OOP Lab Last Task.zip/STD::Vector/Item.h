//
// Created by _rohtanza_ on 5/13/23.
//

#ifndef STD__VECTOR_ITEM_H
#define STD__VECTOR_ITEM_H


#include <string>

class Item {

    std::string itemName;
    std::string itemPrice;

public:
    const std::string &getItemName() const;

    const std::string &getItemPrice() const;

    Item(const std::string &itemName, const std::string &itemPrice);
};


#endif //STD__VECTOR_ITEM_H
