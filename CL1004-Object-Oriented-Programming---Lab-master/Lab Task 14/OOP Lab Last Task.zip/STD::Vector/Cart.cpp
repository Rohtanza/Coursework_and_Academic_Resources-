//
// Created by _rohtanza_ on 5/13/23.
//

#include <iostream>
#include <iomanip>
#include "Cart.h"

const std::string Cart::products[2][6] = {
        {"Bread", "Eggs",  "Milk",  "Butter", "Oatmeal", "Honey"},
        {"100 ₹", " 40 ₹", "140 ₹", "200 ₹",  "350 ₹",   "1000 ₹"}
};


Cart::Cart() {
    shoppingCart = new std::vector<Item>();
    operations();
    distoryCart();
    exit(0);
}

void Cart::distoryCart() {
    delete shoppingCart;
}

void Cart::operations() {
    char choice;

    while (true) {
        Menu();
        std::cout << "Enter your choice:", std::cin >> choice;
        switch (choice) {
            case 'A':
            case 'a':
                addItem();
                break;
            case 'R':
            case 'r':
                removeItem();
                break;
            case 'C':
            case 'c':
                clearCart();
                break;
            case 'U':
            case 'u':
                updateCart();
                break;
            case 'E':
            case 'e':
                exit(0);
                return;
            default:
                std::cout << "Enter a valid choice." << std::endl;
                break;

        }

    }

}

void Cart::addItem() {

    int choice = -1;
    productList();
    std::cout << "Enter your choice of product as per the no: ", std::cin >> choice;
    switch (choice) {
        case 1:
            shoppingCart->push_back(Item(products[0][0], products[1][0]));
            break;
        case 2:
            shoppingCart->push_back(Item(products[0][1], products[1][1]));
            break;
        case 3:
            shoppingCart->push_back(Item(products[0][2], products[1][2]));
            break;
        case 4:
            shoppingCart->push_back(Item(products[0][3], products[1][3]));
            break;
        case 5:
            shoppingCart->push_back(Item(products[0][4], products[1][4]));
            break;
        case 6:
            shoppingCart->push_back(Item(products[0][5], products[1][5]));
            break;
        default:
            std::cout << "Invalid choice, kindly enter right option" << std::endl;
            return;

    }
    std::cout << "Product Added." << std::endl;
    displayCart();
}

void Cart::removeItem() {
    int choice = -1;
    int size = shoppingCart->size();
    displayCart();
    std::cout << "Enter the product no to remove:", std::cin >> choice;
    if (withinRange(0, size, choice)) {
        shoppingCart->erase(shoppingCart->begin() + choice - 1);
        std::cout << "Item is removed from the shopping cart." << std::endl;
    } else {
        std::cout << "Invalid position, Item could not be removed." << std::endl;
        return;
    }

}

void Cart::clearCart() {
    if (isEmpty()) {
        std::cout << "Cant Clear cart as it is already clean" << std::endl;
    } else {
        shoppingCart->clear();
        std::cout << "Cart has been cleared" << std::endl;
    }
}

void Cart::updateCart() {
    if (!isEmpty()) {
        int choice = -1;
        int size = shoppingCart->size();
        displayCart();
        std::cout << "Enter your choice of product to update: ", std::cin >> choice;
        if (withinRange(0, size, choice)) {
            shoppingCart->erase(shoppingCart->begin() + choice - 1);
            std::cout << "product at choice " << choice << " Delete." << std::endl;
        } else {
            std::cout << "Invalid position, Item could not be update." << std::endl;
            return;
        }
        productList();
        std::cout << "Enter your choice of product to updated with: ", std::cin >> choice;
        std::cout << "product at choice " << choice << " is gonna update." << std::endl;
        if (choice >= 1 && choice <= 6) {
            shoppingCart->push_back(Item(products[0][choice - 1], products[1][choice - 1]));
            std::cout << "Product Updated." << std::endl;
            displayCart();

        } else {
            std::cout << "Invalid position, Item could not be update." << std::endl;
            return;
        }
    } else {
        std::cout << "Cant Update item as the cart is already empty." << std::endl;
    }

}

void Cart::Menu() {

    std::cout
            << "Menu:\n\t\t* A for Add items.\n\t\t* R for Removing items.\n\t\t* C for Clear the chart.\n\t\t* U for Updating items.\n\t\t* E for Exit."
            << std::endl;
}

bool Cart::isEmpty() {
    return shoppingCart->empty();
}

void Cart::productList() {
    std::cout << std::setw(10) << std::left << "No." << std::setw(10) << std::left << "Product" << "Price" << std::endl;
    std::cout << "------------------------------------" << std::endl;

    for (int i = 0; i < 6; ++i) {
        std::cout << std::setw(10) << std::left << i + 1 << std::setw(10) << std::left << products[0][i]
                  << products[1][i] << std::endl;
    }


}

void Cart::displayCart() {
    std::cout << "+------------------+------------+" << std::endl;
    std::cout << "|    Item Name     |  Item Price |" << std::endl;
    std::cout << "+------------------+------------+" << std::endl;

    for (const auto &item: *shoppingCart) {
        std::cout << "| " << std::setw(16) << std::left << item.getItemName() << " | " << std::setw(10) << std::right
                  << item.getItemPrice() << " |" << std::endl;
    }

    std::cout << "+------------------+------------+" << std::endl;

}

bool Cart::withinRange(int low, int high, int choice) {
    return ((choice - low) <= (high - low));
}

