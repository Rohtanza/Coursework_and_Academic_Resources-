//
// Created by _rohtanza_ on 5/13/23.
//

#include "Item.h"

Item::Item(const std::string &itemName, const std::string &itemPrice) : itemName(itemName), itemPrice(itemPrice) {}

const std::string &Item::getItemName() const {
    return itemName;
}

const std::string &Item::getItemPrice() const {
    return itemPrice;
}
