#include <iostream>

template <class V>
class Vector {
private:
    V v;

public:
    explicit Vector(V v) : v(v) {}

    [[nodiscard]] double calculateDotProduct(const V& object) const {
        return v.calculateDotProduct(object);
    }
};

class My2DVector {
private:
    double x;
    double y;

public:
    explicit My2DVector(double x = 0, double y = 0) : x(x), y(y) {}

    [[nodiscard]] double calculateDotProduct(const My2DVector& vector) const {
        return x * vector.x + y * vector.y;
    }

    friend std::ostream& operator<<(std::ostream& os, const My2DVector& vector) {
        os << "(" << vector.x << ", " << vector.y << ")";
        return os;
    }

    friend std::istream& operator>>(std::istream& is, My2DVector& vector) {
        is >> vector.x >> vector.y;
        return is;
    }
};

class My3DVector {
private:
    double x;
    double y;
    double z;

public:
    explicit My3DVector(double x = 0, double y = 0, double z = 0) : x(x), y(y), z(z) {}

    [[nodiscard]] double calculateDotProduct(const My3DVector& vector) const {
        return x * vector.x + y * vector.y + z * vector.z;
    }

    friend std::ostream& operator<<(std::ostream& os, const My3DVector& vector) {
        os << "(" << vector.x << ", " << vector.y << ", " << vector.z << ")";
        return os;
    }

    friend std::istream& operator>>(std::istream& is, My3DVector& vector) {
        is >> vector.x >> vector.y >> vector.z;
        return is;
    }
};

int main() {
    My2DVector vector2D1, vector2D2;
    My3DVector vector3D1, vector3D2;

    std::cout << "Enter values for 2D Vector 1 (x y): ";
    std::cin >> vector2D1;

    std::cout << "Enter values for 2D Vector 2 (x y): ";
    std::cin >> vector2D2;

    std::cout << "Enter values for 3D Vector 1 (x y z): ";
    std::cin >> vector3D1;

    std::cout << "Enter values for 3D Vector 2 (x y z): ";
    std::cin >> vector3D2;

    Vector<My2DVector> vectorObj2D1(vector2D1);
    Vector<My2DVector> vectorObj2D2(vector2D2);

    Vector<My3DVector> vectorObj3D1(vector3D1);
    Vector<My3DVector> vectorObj3D2(vector3D2);

    double dotProduct2D = vectorObj2D1.calculateDotProduct(vector2D2);
    double dotProduct3D = vectorObj3D1.calculateDotProduct(vector3D2);

    std::cout << "2D Vector 1: " << vector2D1 << std::endl;
    std::cout << "2D Vector 2: " << vector2D2 << std::endl;
    std::cout << "Dot Product of 2D Vectors: " << dotProduct2D << std::endl;

    std::cout << "3D Vector 1: " << vector3D1 << std::endl;
    std::cout << "3D Vector 2: " << vector3D2 << std::endl;
    std::cout << "Dot Product of 3D Vectors: " << dotProduct3D << std::endl;

    return 0;
}
