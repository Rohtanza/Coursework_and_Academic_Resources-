//
// Created by rohtanza on 11/27/23.
//

#ifndef BOOKSMANAGEMENTSYSTEM_DATE_H
#define BOOKSMANAGEMENTSYSTEM_DATE_H


class Date {
public:
    int day;
    int month;
    int year;

    Date(int day, int month, int year) : day(day), month(month), year(year) {}

};


#endif //BOOKSMANAGEMENTSYSTEM_DATE_H
