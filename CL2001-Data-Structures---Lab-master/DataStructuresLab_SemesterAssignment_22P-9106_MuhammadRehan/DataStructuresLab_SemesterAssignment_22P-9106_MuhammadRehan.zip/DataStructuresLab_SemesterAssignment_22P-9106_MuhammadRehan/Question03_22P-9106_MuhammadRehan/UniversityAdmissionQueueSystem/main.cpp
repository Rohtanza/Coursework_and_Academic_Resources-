#include "operations.cpp"
 /*
  *  Muhammad Rehan 22P-9106
  *
  *  DSA LAB semester assignment question no 3
  *  Program terminal Design is normal but
  *  the code is good. 😊
  *
  * */


int main() {
    // setting seed for the rand function i will use in the operation file.
    srand(static_cast<unsigned int>(time(0)));
    // lets start
    operation();
    return 0;
}
