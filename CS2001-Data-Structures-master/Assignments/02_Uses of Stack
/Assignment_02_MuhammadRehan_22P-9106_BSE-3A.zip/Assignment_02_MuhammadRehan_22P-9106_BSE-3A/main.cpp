#include <iostream>
#include <limits>
#include "StackLinkedList.h"

int main() {

    /*
     * This function "postfixExpression()" follows a convention of that
     * PostFix Expressions always starts with an operand, and it only
     * performs evaluation on a proper postfix, mean with operator count
     * coordinates with operands count. it will throw a exception on a
     * non-proper postfix expression.
     * */

    while (true) {
        char option('0');
        cout << "1. Postfix Expression Function\n2. Matching Brackets\n3. Exit\n=>", cin >> option;
        switch (option) {
            case '1': {
                string inputString;
                //  cin.ignore(numeric_limits<streamsize>::max(), '\n') just cleans the input buffer stream.
                cout << "Enter the string (with spaces): ", cin.ignore(numeric_limits<streamsize>::max(),'\n'), getline(cin, inputString);
                cout << "Result : " << postfixExpression(inputString) << endl;
            }
                break;
            case '2': {
                string inputString;
                //  cin.ignore(numeric_limits<streamsize>::max(), '\n') just cleans the input buffer stream.
                cout << "Enter the string : ", cin.ignore(numeric_limits<streamsize>::max(), '\n'), getline(cin,inputString);
                if (matchingBracket(inputString)) { cout << "Brackets are Matched" << endl; }
                else { cout << "Brackets ain't Matched" << endl; }
            }
                break;
            case '3':
                return 0;
            default:
                cout << "Enter a valid option" << endl;
                break;
        }
    }
}
