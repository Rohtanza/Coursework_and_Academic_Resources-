//
// Created by rohtanza on 10/8/23.
//

#ifndef ASSIGNMENT_02_MUHAMMADREHAN_22P_9106_BSE_3A_STACKLINKEDLIST_H
#define ASSIGNMENT_02_MUHAMMADREHAN_22P_9106_BSE_3A_STACKLINKEDLIST_H


#include <iostream>
#include <memory>
#include <optional>
#include <string>
#include <unordered_set>
#include <unordered_map>
#include <map>
#include <cctype>
#include <functional>
#include <vector>
#include <sstream>
#include <iterator>

using namespace std;
// Sets of opening and closing brackets
unordered_set<char> openingBrackets = {'<', '{', '[', '('};
unordered_set<char> closingBrackets = {'>', '}', ']', ')'};
// A map for matching brackets
unordered_map<char, char> matchingBrackets = {{'>', '<'},
                                              {'}', '{'},
                                              {']', '['},
                                              {')', '('}};

/*The matchingBrackets map is important as
 * it provides an easy way to find the
 * opening bracket that matches closing bracket.
 * It is an unordered_map<char, char> with each closing bracket as a key and its corresponding opening bracket
 * as a value (e.g., {'>', '<'}).
 * */


template<typename dataType>
class StackLinkedList {

    class Node {

        dataType data;
        unique_ptr<Node> next;

    public:
        explicit Node(dataType data) : data(data), next(nullptr) {}

        /* Making node class friend of StackLinkedList will
         * allow StackLinkedList to directly manage the memory of
         * The node objects, without needing to expose the node
         * class.
         * */

        friend class StackLinkedList;

    };

    unique_ptr<Node> top;

    size_t size;

public:
    explicit StackLinkedList() : size(0), top(nullptr) {};

    bool push(dataType data);

    dataType pop();

    /* using optional as I am not sure if the stack is empty
     * what if the stack is empty? then it will return the nullopt
     * meaning the stack is empty.
    */
    dataType topElement();

    size_t sizeStack();

    bool empty();

    void display();

};

template<typename dataType>
size_t StackLinkedList<dataType>::sizeStack() {
    return size;
}

template<typename dataType>
bool StackLinkedList<dataType>::empty() {
    return size == 0;
}

template<typename dataType>
dataType StackLinkedList<dataType>::topElement() {
    if (empty())
        return 0;
    return top->data;

}

template<typename dataType>
dataType StackLinkedList<dataType>::pop() {
    // Checking if the stack is empty.
    if (empty())
        throw out_of_range("Stack underflow\n");
    dataType temp = top->data;
    top = move(top->next);
    size--;
    return temp;
}

template<typename dataType>
bool StackLinkedList<dataType>::push(dataType data) {
    /* First check in the push function is if the
     * memory for new node is allocated, I am using
     * the try and catch block for this. Try will
     * create a new node using unique ptr, if it
     * doesn't happen, it will catch the bad_alloc
     * exception, then an error using the standard
     * error stream will be shown, and that .what()
     * will return a string matching the exception.
     */
    unique_ptr<Node> newNode;
    try {
        //newNode will be automatically deleted when it's no longer needed, preventing memory leaks.
        newNode = make_unique<Node>(data);
    } catch (const bad_alloc &node) {
        cerr << "Memory Allocation failed " << node.what() << endl;
        return false;
    }
    newNode->next = move(top);
    top = move(newNode);
    size++;
    return true;
}

template<typename dataType>
void StackLinkedList<dataType>::display() {
    const Node *current = top.get(); // Using a const pointer to avoid modifying top
    while (current != nullptr) {
        cout << current->data << " -> ";
        current = current->next.get();
    }
    cout << " End." << endl;
}

void cleanString(string &inputString) {
    for (int i = 0; i < inputString.size(); i++) {
        // Check if the character is not in the set of allowed characters
        if (inputString[i] != '<' && inputString[i] != '>' && inputString[i] != '(' && inputString[i] != ')' &&
            inputString[i] != '[' && inputString[i] != ']' && inputString[i] != '{') {
            inputString.erase(i, 1);
            i--;
        }
    }
}

bool matchingBracket(string &inputString) {
    //Creating a Stack
    cleanString(inputString);
    // Cleaning the string, so it only contain the brackets, nothing else.
    cout << inputString << endl;
    auto bracketStack = make_unique<StackLinkedList<char>>();
    string outputString;
    //Iterating through the whole string
    for (char i: inputString)
        if (openingBrackets.count(i)) // If 'i' is an opening bracket, it'll go to stack and outputString both.
            bracketStack->push(i), outputString += i;
        else if (closingBrackets.count(i))
            /* if 'i' is a closing bracket,
             * it'll check if stack ain't empty plus closing bracket
             * matches the opening bracket at the top of the stack.
             * MatchingBrackets map is used to find the opening bracket
             * that matches the closing bracket i. If both conditions are true,
             * it pops the opening bracket from the stack and adds i to outputString.
             * */
            if (!bracketStack->empty() && bracketStack->topElement() == matchingBrackets[i])
                bracketStack->pop(), outputString += i;
    if (bracketStack->empty())
        return true;
    return false;

}

// These funs do the basic arithmetic operations on two int inputs and return the results
double add(double a, double b) { return a + b; }

double subtract(double a, double b) { return a - b; }

double multiply(double a, double b) { return a * b; }

double divide(double a, double b) {
    //check to prevent division by zero, which would be undefined.
    if (b == 0) {
        throw invalid_argument("Division by zero is not allowed.");
    }
    return a / b;
}

double postfixExpression(string &expression) {
    auto resultStack = make_unique<StackLinkedList<double>>();
    string equation;
    // I don't know if user enters junk chars with the expression so cleaning the equation.
    // removing any non-numeric or non-operator characters.
    for (char i: expression)
        if (isspace(i) || isdigit(i) || i == '+' || i == '-' || i == '*' || i == '/')
            equation += i;
    /*The cleaned string is now getting cut into tokens using a space (' ')
     * as the parameter. Each token is now a number or an operator.
     * These tokens are stored in a vector of strings.
     * */
    vector<string> tokens;
    string token;
    for (char i: expression) {
        if (i == ' ') {
            if (!token.empty()) {
                tokens.push_back(token);
                token.clear();
            }
        } else {
            token += i;
        }
    }
    if (!token.empty()) {
        tokens.push_back(token);
    }
    //This maps will map (match) each operator to its matching operation function.
    map<char, function<double(double, double)>> operations = {
            {'+', add},
            {'-', subtract},
            {'*', multiply},
            {'/', divide}
    };
    /* The for below iterates over each token in the vector,
     * if a token is a number, it is converted to a double and pushed onto the stack.
     * if a token is an operator, the function pops two numbers from the stack,
     * performs the operation by matching operator in the map,
     * and pushes the result back onto the stack.
     * */
    for (const auto &token: tokens) {
        /*The all_of function from <algorithm> lib is used to
         * check if all chars in the token are digits.
         * if all chars are digits, the token is converted
         * to a double using the stod function and then
         * pushed onto the resultStack .
         * */
        if (all_of(token.begin(), token.end(), ::isdigit)) {
            double number = stod(token);
            resultStack->push(number);
        } else {
            /* if the token is not a number,
             * it's an operation. The topElement function
             * is called twice to get the top two elements
             * from the resultStack, which are operands for the operation.
             * These two operands are popped from the resultStack to make room
             * for the result of the operation.
             * */
            double operandTwo = resultStack->topElement();
            resultStack->pop();
            double operandOne = resultStack->topElement();
            resultStack->pop();
            /* The operation is performed by calling the function associated
             * with first char of the token in the operations map,
             * The result of the operation is again pushed onto resultStack.
             * */
            resultStack->push(operations[token[0]](operandOne, operandTwo));
        }
    }
    return resultStack->topElement();
}


#endif //ASSIGNMENT_02_MUHAMMADREHAN_22P_9106_BSE_3A_STACKLINKEDLIST_H
