#include <iostream>
#include "LinkedList.h"

using namespace std;

int main() {
    int N, M;
    cout << "Total persons in the circle: ", cin >> N;
    cout << "Skip size while counting: ", cin >> M;
    LinkedList list;
    int lastManStanding = list.josephus(N, M);
    cout << "The Last Man Standing : " << lastManStanding << std::endl;
    return EXIT_SUCCESS;
}
