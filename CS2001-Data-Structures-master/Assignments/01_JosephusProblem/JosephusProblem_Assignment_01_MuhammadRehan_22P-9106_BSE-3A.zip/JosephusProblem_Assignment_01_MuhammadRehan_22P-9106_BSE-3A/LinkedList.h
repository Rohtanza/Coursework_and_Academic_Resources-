//
// Created by rohtanza on 9/20/23.
//

#ifndef JOSEPHUSPROBLEM_ASSIGNMENT_01_LINKEDLIST_H
#define JOSEPHUSPROBLEM_ASSIGNMENT_01_LINKEDLIST_H


class LinkedList {
private:
    class Node {
    public:
        int value;
        Node *next;

        Node(int val) : value(val), next(nullptr) {}
    };

    Node *head;

public:
    LinkedList();

    int josephus(int N, int M);

};


#endif //JOSEPHUSPROBLEM_ASSIGNMENT_01_LINKEDLIST_H
