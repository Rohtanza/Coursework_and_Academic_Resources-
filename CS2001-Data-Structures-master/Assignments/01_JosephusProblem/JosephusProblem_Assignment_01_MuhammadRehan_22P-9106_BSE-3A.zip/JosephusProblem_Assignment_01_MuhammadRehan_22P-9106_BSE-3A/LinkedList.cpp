//
// Created by rohtanza on 9/20/23.
//

#include "LinkedList.h"

LinkedList::LinkedList() : head(nullptr) {}

int LinkedList::josephus(int N, int M) {
    for (int i = 1; i <= N; ++i) {
        Node *newNode = new Node(i);
        if (!head) {
            head = newNode;
            head->next = head;
        } else {
            Node *current = head;
            while (current->next != head) {
                current = current->next;
            }
            current->next = newNode;
            newNode->next = head;
        }
    }

    Node *current = head;
    Node *prev = nullptr;
    int count = 0;
    while (current->next != current) {
        count++;
        if (count == M) {
            prev->next = current->next;
            delete current;
            current = prev->next;
            count = 0;
        } else {
            prev = current;
            current = current->next;
        }
    }
    return current->value;
}

