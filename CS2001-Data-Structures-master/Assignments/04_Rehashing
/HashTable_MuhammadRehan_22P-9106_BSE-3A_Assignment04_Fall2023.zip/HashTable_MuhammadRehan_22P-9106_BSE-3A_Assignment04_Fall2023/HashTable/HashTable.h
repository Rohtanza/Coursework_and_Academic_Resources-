#ifndef HASHTABLE_HASHTABLE_H
#define HASHTABLE_HASHTABLE_H

#include <vector>
#include <cstdlib>
#include <iostream>

template<typename K, typename V>
class HashTable {

    class Entity {
        K key;
        V value;
    public:
        Entity(K key, V value) : key(key), value(value) {}

        friend class HashTable;
    };

    /**
   *  I am creating a vector with each index is a vector
   *  itself of the entity(key and value), i am using the way
   *  mention in the end of the lecture slides, open hashing,
   *  (chaining)
   * */
    std::vector<std::vector<Entity>> list;
    /* This is my parameter, which its archived then I will
   * rehash my table. here I am using 0.5 means when my table
   * is half full, I am going to rehash it
   * */
    size_t size = 0;
    double loadFactor = 0.5;

public:

    HashTable(size_t initialSize = 10) : list(initialSize) {}

    V Get(K key) {
        int hash = abs(std::hash<K>{}(key) % list.size());
        std::vector<Entity> &entities = list[hash];

        for (Entity &entity: entities) {
            if (entity.key == key)
                return entity.value;
        }
        return V();
    }

    void put(K key, V value) {
        /*here I am using the cpp hash function which is
         * best for preventing collisions, using a weak hash
         * function is stupid as increases the chances of rehashing
         * which is an expensive process.
         * */

        int hash = abs(std::hash<K>{}(key) % list.size());
        std::vector<Entity> &entities = list[hash];

        for (Entity &entity: entities) {
            if (entity.key == key) {
                entity.value = value;
                return;
            }
        }
        if ((float) (size) / list.size() > loadFactor) {
            rehashing();
            hash = abs(std::hash<K>{}(key) % list.size());
            entities = list[hash];
        }
        entities.push_back(Entity(key, value));
        size++;
    }

    void remove(K key) {
        int hash = abs(std::hash<K>{}(key) % list.size());
        std::vector<Entity> &entities = list[hash];

        for (auto it = entities.begin(); it != entities.end(); ++it) {
            if (it->key == key) {
                entities.erase(it);
                size--;
                break;
            }
        }
    }

    bool doesContainKey(K key) {
        return Get(key) != V();
    }

    void rehashing() {
        // Print a cool message to indicate that rehashing is going to start

        std::cout << "\n"
                     "██████╗ ███████╗██╗  ██╗ █████╗ ███████╗██╗  ██╗██╗███╗   ██╗ ██████╗ \n"
                     "██╔══██╗██╔════╝██║  ██║██╔══██╗██╔════╝██║  ██║██║████╗  ██║██╔════╝ \n"
                     "██████╔╝█████╗  ███████║███████║███████╗███████║██║██╔██╗ ██║██║  ███╗\n"
                     "██╔══██╗██╔══╝  ██╔══██║██╔══██║╚════██║██╔══██║██║██║╚██╗██║██║   ██║\n"
                     "██║  ██║███████╗██║  ██║██║  ██║███████║██║  ██║██║██║ ╚████║╚██████╔╝\n"
                     "╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝ \n"
                     "                                                                      " << std::endl;
        // Create a copy of our current hash table
        std::vector<std::vector<Entity>> old = list;
        // Clear the current hash table and set the size to zero.
        list.clear();
        size = 0;
        // Double the size of our hash table
        for (int i = 0; i < old.size() * 2; ++i) {
            list.push_back(std::vector<Entity>());
        }
        // Rehash the elements from the old hash table into our new hashtable.
        for (std::vector<Entity> &entries: old) {
            for (Entity &entry: entries) {
                // Calculate the hash of the key and find the corresponding pair in the new hash table
                int hash = abs(std::hash<K>{}(entry.key) % list.size());
                // Add the entity to the new bucket
                list[hash].push_back(entry);
                // Increment the size of our hash table
                size++;
            }
        }
    }

    void display() {
        if (!list.empty()) {
            for (size_t i = 0; i < list.size(); ++i) {
                std::cout << "Pair " << i << ": ";
                for (const Entity &entity: list[i]) {
                    std::cout << "Key: " << entity.key << ", Value: " << entity.value << " ";
                }
                std::cout << std::endl;
            }
        }
    }

    void printKeyValue(K key) {
        int hash = abs(std::hash<K>{}(key) % list.size());
        std::vector<Entity> &entities = list[hash];

        for (Entity &entity: entities) {
            if (entity.key == key) {
                std::cout << "Key: " << entity.key << ", Value: " << entity.value << std::endl;
                return;
            }
        }
        std::cout << "Key: " << key << " not found in the hash table." << std::endl;
    }

};

#endif //HASHTABLE_HASHTABLE_H
