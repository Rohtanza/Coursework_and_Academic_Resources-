#include <iostream>
#include "HashTable.h"
#include <random>
#include <string>


/*
 * the function below is just a function which generates a random
 * string for us to put in our pair in our hashtable.
 * */

std::string generateRandomString(int length) {

    /*
     * Its just using CPP redefined algo to do the job.
     * */
    std::string possibleCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    std::random_device rd;
    std::mt19937 generator(rd());
    std::uniform_int_distribution<> distrib(0, possibleCharacters.size() - 1);

    std::string randomString;
    randomString.reserve(length);

    for (int i = 0; i < length; i++) {
        randomString += possibleCharacters[distrib(generator)];
    }

    return randomString;
}


int main() {
    // make a hash table
    HashTable<int, std::string> hashTable;

    int key;
    std::cout << "Enter -1 as a key to end our endless loop" << std::endl;
    while (true) {
        // now we're going to put putting values unless it rehashing
        std::cout << "Key :", std::cin >> key;
        if (key == -1)break;
        // take mod with 10 , coz we dont want our string to be very long.
        hashTable.put(key, generateRandomString(key % 10));
        hashTable.printKeyValue(key);
    }
    // display the contents of the hash table
    hashTable.display();

    return 0;
}
