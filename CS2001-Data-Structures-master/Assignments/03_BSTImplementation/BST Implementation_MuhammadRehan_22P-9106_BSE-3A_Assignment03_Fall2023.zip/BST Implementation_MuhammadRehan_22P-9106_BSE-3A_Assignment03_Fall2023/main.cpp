#include <iostream>
#include "BST.h"

void displayTree(BST<int> *tree) {
    // Created a different method to display tree in each order
    while (true) {
        char option('0');
        cout
                << "\nWhich traversal do you want\n1. Pre-order\n2. In-order\n3. Post-order\n4. Level Order Traversal\n5. Exit\n=>",
                cin >> option;
        switch (option) {
            case '1':
                tree->preOrder();
                break;
            case '2':
                tree->inOrder();
                break;
            case '3':
                tree->postOrder();
                break;
            case '4':
                tree->levelOrderTraversal();
                break;
            case '5':
                return;
            default:
                cout << "Enter valid option" << endl;
                break;
        }
    }

}

int main() {

    BST<int> *tree = new BST<int>;
    char option('@');
    while (true) {
        cout
                << "1. Insert\n" "2. Delete\n" "3. Search\n" "4. Display\n" "5. Traversal\n" "6. Find Minimum\n" "7. Find Maximum\n" "8. Is Empty?\n" "0. Quit\n" "Enter your choice: ",
                cin >> option;

        switch (option) {
            case '1': {
                /*
                 * I am putting values using an array to
                 * make it easy for you to test it
                 * without the difficulty of entering
                 * values, just update the array and
                 * it will add the value saving you
                 * time
                 *
                 * */
                int array[] = {8, 3, 10, 1, 6, 14, 4, 7, 13};
//                int value;
//                cout << "Enter the value: ", cin >> value;
                for (auto i: array)
                    tree->insert(i);
            }
                break;
            case '2': {
                int value;
                cout << "Enter the value to be deleted: ", cin >> value;
                tree->Delete(value);
            }
                break;
            case '3': {
                int value;
                cout << "Enter the value to be search: ", cin >> value;
                cout << tree->searchNode(value) << endl;
            }
                break;
            case '4': {
                tree->displayTree();
            }
                break;
            case '5': {
                displayTree(tree);
            }
                break;
            case '6': {
                cout << "Minimum : " << tree->findMin() << endl;
            }
                break;
            case '7': {
                cout << "Maximum : " << tree->findMax() << endl;
            }
                break;
            case '8': {
                if (tree->isEmpty()) cout << "Tree is Empty." << endl;
                else cout << "Tree is not Empty." << endl;
            }
                break;
            case '0': {
                delete tree;
                return EXIT_SUCCESS;
            }
            default:
                break;

        }


    }


}
